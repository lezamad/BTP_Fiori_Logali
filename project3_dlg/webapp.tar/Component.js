sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function(AppComponent) {
    return AppComponent.extend("nsdlg02.project2.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
